This folder is used only to support [meson.build](../meson.build) `subproject` command
which would only look for a subproject in a "subprojects" directory.